<section id="main-content" class="d-flex flex-column justify-content-center bg-white p-2 rounded" style="overflow: auto;">
  <div class="container" data-aos="fade-up">
    <div class="row d-flex align-items-center mb-2">
      <div class="col-md-8 col-12">
        <h2>
          <strong>Report Bulan <span id="setBulan">Januari</span></strong>
        </h2>
      </div>
      <div class="col-md-2 col-12">
        <select name="filterType" id="filterType" class="form-control">
          <option value="pembelian">Pembelian</option>
          <option value="penjualan">Penjualan</option>
        </select>
      </div>
      <div class="col-md-1 col-12">
        <select name="filterTahun" id="filterTahun" class="form-control">
          <!-- Diisi JavaScript -->
        </select>
      </div>
      <div class="col-md-1 col-12">
        <select name="filterBulan" id="filterBulan" class="form-control" onchange="pickBulan(this.value)">
          <option value="01-Januari">Januari</option>
          <option value="02-Februari">Februari</option>
          <option value="03-Maret">Maret</option>
          <option value="04-April">April</option>
          <option value="05-Mei">Mei</option>
          <option value="06-Juni">Juni</option>
          <option value="07-Juli">Juli</option>
          <option value="08-Agustus">Agustus</option>
          <option value="09-September">September</option>
          <option value="10-Oktober">Oktober</option>
          <option value="11-November">November</option>
          <option value="12-Desember">Desember</option>
        </select>
      </div>
    </div>
    <div class="bg-white">
      <table class="table table-striped table-bordered" id="table-report">
        <thead>
          <tr>
            <th>#</th>
            <th>Nama Marketplace</th>
            <th>Persen Fee</th>
            <th>##</th>
          </tr>
        </thead>
        <tbody id="content-table">
          <!-- Diisi JavaScript -->
        </tbody>
      </table>
    </div>
  </div>
</section>

<script>
  $(function() {
    setDate()
  })

  async function getReport() {
    
    // $('#table-report').DataTable()
  }

  function setDate() {
    let d = new Date()
    let content = `
      <option value="${d.getFullYear()}">${d.getFullYear()-1}</option>
      <option value="${d.getFullYear()}" selected>${d.getFullYear()}</option>
      <option value="${d.getFullYear()}">${d.getFullYear()+1}</option>
    `
    document.getElementById('filterTahun').innerHTML = content
  }

  function pickBulan(val) {
    let split = val.split('-')
    document.getElementById('setBulan').innerHTML = split[1]
  }
</script>